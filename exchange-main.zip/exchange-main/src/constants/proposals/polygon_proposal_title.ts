export const POLYGON_PROPOSAL_TITLE = 'Should Uniswap v3 be deployed to Polygon?'
