export enum FeatureFlag {
  fiatOnramp = 'fiatOnramp',
  traceJsonRpc = 'traceJsonRpc',
  permit2 = 'permit2',
  nftListV2 = 'nftListV2',
  payWithAnyToken = 'payWithAnyToken',
  swapWidget = 'swapWidget',
}
