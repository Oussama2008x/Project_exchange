**Do not edit translation files manually**

## Contributing

Translation files in this folder are automatically generated from our [Crowdin project](https://crowdin.com/project/uniswap-interface).

See [CONTRIBUTING](https://github.com/Uniswap/uniswap-interface/blob/main/CONTRIBUTING.md#translations) on how to get started.
